package com.example.interbal;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class RegisterActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth fireauth;
    private EditText reg_firstname, reg_lastname, reg_studno, reg_course, reg_contact, reg_email, reg_username, reg_password, reg_confirm;
    private Button reg_button;
    private TextView loginRedirectText;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        FirebaseApp.initializeApp(this);
        firebaseAuth = FirebaseAuth.getInstance();
        fireauth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        reg_button = findViewById(R.id.reg_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);

        reg_firstname = findViewById(R.id.reg_firstname);
        reg_lastname = findViewById(R.id.reg_lastname);
        reg_studno = findViewById(R.id.reg_studno);
        reg_course = findViewById(R.id.reg_course);
        reg_contact = findViewById(R.id.reg_contact);
        reg_email = findViewById(R.id.reg_email);
        reg_username = findViewById(R.id.reg_username);
        reg_password = findViewById(R.id.reg_password);
        reg_confirm = findViewById(R.id.reg_password2);


        reg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });

        loginRedirectText.setOnClickListener(v -> startActivity(new Intent(RegisterActivity.this, LoginActivity.class)));

    }

    private void register() {
        String firstname = reg_firstname.getText().toString().trim();
        String lastname = reg_lastname.getText().toString().trim();
        String studno = reg_studno.getText().toString().trim();
        String course = reg_course.getText().toString().trim();
        String contact = reg_contact.getText().toString().trim();
        String email = reg_email.getText().toString().trim();
        String username = reg_username.getText().toString().trim();
        String password = reg_password.getText().toString().trim();
        String confirm = reg_confirm.getText().toString().trim();

        String history = "history";
        String firstsem = "firstsem";
        String secondsem = "secondsem";


        if (TextUtils.isEmpty(firstname)) {
            reg_firstname.setError("Please enter your first name!");
            return;
        }


        if (TextUtils.isEmpty(lastname)) {
            reg_lastname.setError("Please enter your last name!");
            return;
        }

        if (TextUtils.isEmpty(studno)) {
            reg_studno.setError("Please enter your student number!");
            return;
        }

        if (TextUtils.isEmpty(course)) {
            reg_course.setError("Please enter your course!");
            return;
        }

        if (TextUtils.isEmpty(contact)) {
            reg_contact.setError("Please enter your contact number!");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            reg_email.setError("Please enter your email!");
            return;
        }

        if (TextUtils.isEmpty(username)) {
            reg_username.setError("Please enter your username!");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            reg_password.setError("Please enter your password!");
            return;
        }

        if (TextUtils.equals(password, confirm)) {

        } else {
            reg_confirm.setError("Password do not match");
            return;
        }


        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String userId = firebaseAuth.getCurrentUser().getUid();
                            Users user = new Users(userId, firstname, lastname, studno, course, contact, email, username, password,  0.0, history, firstsem, secondsem);

                            databaseReference.child(userId).setValue(user)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(getApplicationContext(), "Registration successfuly", Toast.LENGTH_SHORT).show();

                                                reg_firstname.setText("");
                                                reg_lastname.setText("");
                                                reg_studno.setText("");
                                                reg_course.setText("");

                                                reg_contact.setText("");
                                                reg_email.setText("");
                                                reg_username.setText("");
                                                reg_password.setText("");
                                                reg_confirm.setText("");


                                            } else {
                                                Toast.makeText(getApplicationContext(), "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                        } else {
                            Toast.makeText(getApplicationContext(), "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}