package com.example.interbal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;

    ArrayList<User> list;

    String test;


    public MyAdapter(Context context, ArrayList<User> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        User user = list.get(position);
        holder.now.setText(user.getNow()); //july
        holder.balance.setText(user.getBalance());
        holder.addedbal.setText(user.getAddedbal());
        holder.status.setText(user.getStatus());
//        holder.balance.setText(user.getBalance());
//        holder.addedbal.setText(user.getAddedbal());





        // holder.lastname.setText(user.getLastname());
        // holder.age.setText(user.getAge());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView now,balance, addedbal,status, lastName, age;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
                now = itemView.findViewById(R.id.tvdate);
                balance = itemView.findViewById(R.id.totalview);
                addedbal = itemView.findViewById(R.id.comview);
                status = itemView.findViewById(R.id.tvstat);

                // = itemView.findViewById(R.id.tvlastName);
                 // age = itemView.findViewById(R.id.tvage);

//            itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Log.d("demo","row isclicked" + test);
//
//                }
//            });
//
//            itemView.findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Log.d("demo","Onclick: Like for user");
//                }
//            });

        }
    }

}
