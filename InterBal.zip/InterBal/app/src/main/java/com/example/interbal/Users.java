package com.example.interbal;

public class Users {
    private String userId, firstname, lastname, studno, course, contact, email, username, password ,history, firstsem, secondsem;

    private double balance;

    public Users() {
        // Default constructor required for Firebase
    }


    public Users(String userId, String firstname, String lastname, String studno, String course, String contact, String email, String username, String password, double balance,String history,String firstsem,String secondsem) {
        this.userId = userId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.studno = studno;
        this.course = course;
        this.contact = contact;
        this.email = email;
        this.username = username;
        this.password = password;
        this.history = history;
        this.firstsem = firstsem;
        this.secondsem = secondsem;
    }


    public String getUserId() {
        return userId;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getStudno() {
        return studno;
    }

    public String getCourse() {
        return course;
    }

    public String getContact() {
        return contact;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }


    public double getBalance() { return balance; }

    public String getHistory() {
        return history;
    }
    public String getFirstsem() {
        return firstsem;
    }
    public String getSecondsem() {
        return secondsem;
    }



    public void setUserId() {
        this.userId = userId;
    }

    public void setFirstname() {
        this.firstname = firstname;
    }

    public void setLastname() {
        this.lastname = lastname;
    }

    public void setStudno() {
        this.studno = studno;
    }

    public void setCourse() {
        this.course = course;
    }

    public void setContact() {
        this.contact = contact;
    }

    public void setEmail() {
        this.email = email;
    }

    public void setUsername() {
        this.username = username;
    }

    public void setPassword() {
        this.password = password;
    }

    public void setHistory() {
        this.history = history;
    }
    public void setFirstsem() {
        this.firstsem = firstsem;
    }
    public void setSecondsem() {
        this.firstsem = secondsem;
    }




}
