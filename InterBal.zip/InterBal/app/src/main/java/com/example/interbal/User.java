package com.example.interbal;

public class User {
    String now, balance, addedbal, status ;

    public User(){}



    public User(String now, String balance, String addedbal, String status) {
        this.now = now;
        this.balance = balance;
        this.addedbal = addedbal;
        this.status = status;
    }
    public String getNow() {
        return now; //july
    }

    public String getBalance() {
        return balance;
    }

    public String getAddedbal() {
        return addedbal;
    }
    public String getStatus() {
        return status;
    }


}
