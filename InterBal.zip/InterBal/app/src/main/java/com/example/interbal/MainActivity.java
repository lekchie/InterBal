package com.example.interbal;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

   private TextView profile_firstname, profile_lastname, profile_studno, profile_course, profile_contact, profile_email, profile_username, profile_password;

   private TextView edit_firstname, edit_lastname, edit_studno, edit_course, edit_contact, edit_email, edit_username, edit_password, edit_password2;
   private TextView txt_cash, cash_Contact, cash_Amount;
   public EditText sub1, sub2, sub3, sub4, sub5, sub6, sub7, total;
   public EditText fee1, fee2, fee3, fee4, fee5, fee6, fee7;
   public Button btn_edit, btn_save, btn_pay, btn_1stsem,btn_2ndsem;
   public String sem;

    FirebaseDatabase firebaseDatabase, semdatabase;

    // creating a variable for our Database
    // Reference for Firebase.
    DatabaseReference databaseReference, semreference;


    // creating a variable for
    // our object class
    EmployeeInfo employeeInfo;
    ImageButton btn_history;
    String totalval;
    String check = "togglefirstsem";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton btn_home = findViewById(R.id.btn_home);
        btn_history = findViewById(R.id.btn_history);
        ImageButton btn_profile = findViewById(R.id.btn_profile);
        ImageButton btn_logout = findViewById(R.id.btn_logout);
        Button btn_cashin = findViewById(R.id.btn_cashin);
        Button btn_addcash = findViewById(R.id.btn_addcash);
        Button btn_editProfile = findViewById(R.id.btn_editProfile);
        Button btn_editSave = findViewById(R.id.btn_editSave);
        Button btn_editBack = findViewById(R.id.btn_editBack);



        sub1 = findViewById(R.id.subject1);
        sub2 = findViewById(R.id.subject2);
        sub3 = findViewById(R.id.subject3);
        sub4 = findViewById(R.id.subject4);
        sub5 = findViewById(R.id.subject5);
        sub6 = findViewById(R.id.subject6);
        sub7 = findViewById(R.id.subject7);

        fee1 = findViewById(R.id.fee1);
        fee2 = findViewById(R.id.fee2);
        fee3 = findViewById(R.id.fee3);
        fee4 = findViewById(R.id.fee4);
        fee5 = findViewById(R.id.fee5);
        fee6 = findViewById(R.id.fee6);
        fee7 = findViewById(R.id.fee7);
        total = findViewById(R.id.txt_Total);

        btn_edit = findViewById(R.id.btn_edit);
        btn_save = findViewById(R.id.btn_save);
        btn_pay = findViewById(R.id.btn_pay);
        btn_1stsem = findViewById(R.id.btn_1stsem);
        btn_2ndsem = findViewById(R.id.btn_2ndsem);

        profile_firstname = findViewById(R.id.profile_firstname);
        profile_lastname = findViewById(R.id.profile_lastname);
        profile_studno = findViewById(R.id.profile_studno);
        profile_course = findViewById(R.id.profile_course);
        profile_contact = findViewById(R.id.profile_contact);
        profile_email = findViewById(R.id.profile_email);
        profile_username = findViewById(R.id.profile_username);

        edit_firstname = findViewById(R.id.edit_firstname);
        edit_lastname = findViewById(R.id.edit_lastname);
        edit_studno = findViewById(R.id.edit_studno);
        edit_course = findViewById(R.id.edit_course);
        edit_contact = findViewById(R.id.edit_contact);
        edit_email = findViewById(R.id.edit_email);
        edit_username = findViewById(R.id.edit_username);
        edit_password = findViewById(R.id.edit_password);
        edit_password2 = findViewById(R.id.edit_password2);

        txt_cash = findViewById(R.id.txt_cash);
        cash_Contact = findViewById(R.id.cash_Contact);
        cash_Amount = findViewById(R.id.cash_Amount);


        LinearLayout body_home = findViewById(R.id.body_home);
        LinearLayout body_history = findViewById(R.id.body_history);
        LinearLayout body_profile = findViewById(R.id.body_profile);
        LinearLayout body_editProfile = findViewById(R.id.body_editProfile);
        LinearLayout body_cash = findViewById(R.id.body_cash);

        btn_logout.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, LoginActivity.class )));

        DisplayText();


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();
        DatabaseReference checkref = FirebaseDatabase.getInstance().getReference("users").child(userid);

        btn_1stsem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check = "togglefirstsem";
                btn_1stsem.setBackgroundColor(getResources().getColor(R.color.purple));
                btn_2ndsem.setBackgroundColor(getResources().getColor(R.color.light_purple));
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("First Semester");
                alert.setMessage("Your Data has been changed to First sem");
                alert.setPositiveButton("OK",null);
                alert.show();



                checkref.child("firstsem").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.hasChild("fee1")) {
                            viewfirstsem();
                        }
                        else {
                            Toast.makeText(MainActivity.this, "There is no data to Show", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }

                });


            }
        });
        btn_2ndsem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check = "toggle2ndsem";
                btn_1stsem.setBackgroundColor(getResources().getColor(R.color.light_purple));
                btn_2ndsem.setBackgroundColor(getResources().getColor(R.color.purple));
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Second Semester");
                alert.setMessage("Your Data has been changed to Second sem");
                alert.setPositiveButton("OK",null);
                alert.show();

                checkref.child("secondsem").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.hasChild("fee1")) {
                            viewSecondsem();
                        }
                        else {
                            Toast.makeText(MainActivity.this, "There is no data to Show! Switch to first Semester", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

        btn_cashin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (body_cash.getVisibility() == View.GONE) {
                    body_home.setVisibility(View.GONE);
                    body_profile.setVisibility(View.GONE);
                    body_editProfile.setVisibility(View.GONE);
                    body_history.setVisibility(View.GONE);
                    body_cash.setVisibility(View.VISIBLE);
                }

            }

        });

        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (body_home.getVisibility() == View.GONE) {
                    body_home.setVisibility(View.VISIBLE);
                    body_profile.setVisibility(View.GONE);
                    body_editProfile.setVisibility(View.GONE);
                    body_history.setVisibility(View.GONE);
                    body_cash.setVisibility(View.GONE);

                }

            }

        });

        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (body_profile.getVisibility() == View.GONE) {
                    body_home.setVisibility(View.GONE);
                    body_profile.setVisibility(View.VISIBLE);
                    body_editProfile.setVisibility(View.GONE);
                    body_history.setVisibility(View.GONE);
                    body_cash.setVisibility(View.GONE);
                }

            }
        });

        btn_editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (body_editProfile.getVisibility() == View.GONE) {
                    body_home.setVisibility(View.GONE);
                    body_profile.setVisibility(View.GONE);
                    body_editProfile.setVisibility(View.VISIBLE);
                    body_history.setVisibility(View.GONE);
                    body_cash.setVisibility(View.GONE);
                }

            }
        });

        btn_editBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (body_profile.getVisibility() == View.GONE) {
                    body_home.setVisibility(View.GONE);
                    body_profile.setVisibility(View.VISIBLE);
                    body_editProfile.setVisibility(View.GONE);
                    body_history.setVisibility(View.GONE);
                    body_cash.setVisibility(View.GONE);
                }

            }
        });

        btn_editSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = edit_password.getText().toString().trim();
                String confirm = edit_password2.getText().toString().trim();
                if (TextUtils.equals(password,confirm)) {
                    updateProfile();

                    if (body_editProfile.getVisibility() == View.GONE) {
                        body_home.setVisibility(View.GONE);
                        body_profile.setVisibility(View.VISIBLE);
                        body_editProfile.setVisibility(View.GONE);
                        body_history.setVisibility(View.GONE);
                        body_cash.setVisibility(View.GONE);

                    }
                } else {
                    edit_password2.setError("Password do not match");
                }

            }
        });

        btn_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotohistory();
            }

        });

        btn_addcash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBalance();
            }
        });

        btn_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if (check == "togglefirstsem"){
                       paytofirstsem();
                    }else if(check == "toggle2ndsem") {
                        paytosecondsem();
                    }
            }
        });


        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check != null) {
                    sub1.setEnabled(true);
                    sub2.setEnabled(true);
                    sub3.setEnabled(true);
                    sub4.setEnabled(true);
                    sub5.setEnabled(true);
                    sub6.setEnabled(true);
                    sub7.setEnabled(true);

                    fee1.setEnabled(true);
                    fee2.setEnabled(true);
                    fee3.setEnabled(true);
                    fee4.setEnabled(true);
                    fee5.setEnabled(true);
                    fee6.setEnabled(true);
                    fee7.setEnabled(true);

                    Toast.makeText(getApplicationContext(), "Editing Enabled!", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this, "Please Select a Semester", Toast.LENGTH_SHORT).show();
                }

            }
        });


        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Savebntn();
            }
        });

    }

    private void Savebntn() {

        String myfee1 = fee1.getText().toString();
        String myfee2 = fee2.getText().toString();
        String myfee3 = fee3.getText().toString();
        String myfee4 = fee4.getText().toString();
        String myfee5 = fee5.getText().toString();
        String myfee6 = fee6.getText().toString();
        String myfee7 = fee7.getText().toString();

        int newfee1 = Integer.parseInt(myfee1);
        int newfee2 = Integer.parseInt(myfee2);
        int newfee3 = Integer.parseInt(myfee3);
        int newfee4 = Integer.parseInt(myfee4);
        int newfee5 = Integer.parseInt(myfee5);
        int newfee6 = Integer.parseInt(myfee6);
        int newfee7 = Integer.parseInt(myfee7);

        int vtotal = newfee1 + newfee2 + newfee3 + newfee4 + newfee5 + newfee6 + newfee7;
        String showtotal = String.valueOf(vtotal);

        total.setText(showtotal);


        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setTitle("Editing Saved");
        alert.setMessage("Your Overall total is " + showtotal);
        alert.setPositiveButton("OK",null);
        alert.show();


        sub1.setEnabled(false);
        sub2.setEnabled(false);
        sub3.setEnabled(false);
        sub4.setEnabled(false);
        sub5.setEnabled(false);
        sub6.setEnabled(false);
        sub7.setEnabled(false);

        fee1.setEnabled(false);
        fee2.setEnabled(false);
        fee3.setEnabled(false);
        fee4.setEnabled(false);
        fee5.setEnabled(false);
        fee6.setEnabled(false);
        fee7.setEnabled(false);

    }

    private void viewfirstsem() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(userid);

        ref.child("firstsem").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String vsub1 = dataSnapshot.child("sub1").getValue().toString();
                String vsub2 = dataSnapshot.child("sub2").getValue().toString();
                String vsub3 = dataSnapshot.child("sub3").getValue().toString();
                String vsub4 = dataSnapshot.child("sub4").getValue().toString();
                String vsub5 = dataSnapshot.child("sub5").getValue().toString();
                String vsub6 = dataSnapshot.child("sub6").getValue().toString();
                String vsub7 = dataSnapshot.child("sub7").getValue().toString();

                fee1.setText("0");
                fee2.setText("0");
                fee3.setText("0");
                fee4.setText("0");
                fee5.setText("0");
                fee6.setText("0");
                fee7.setText("0");

                sub1.setText(vsub1);
                sub2.setText(vsub2);
                sub3.setText(vsub3);
                sub4.setText(vsub4);
                sub5.setText(vsub5);
                sub6.setText(vsub6);
                sub7.setText(vsub7);




            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void viewSecondsem() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(userid);

        ref.child("secondsem").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                    String vfee1 = dataSnapshot.child("fee1").getValue().toString();
                    String vfee2 = dataSnapshot.child("fee2").getValue().toString();
                    String vfee3 = dataSnapshot.child("fee3").getValue().toString();
                    String vfee4 = dataSnapshot.child("fee4").getValue().toString();
                    String vfee5 = dataSnapshot.child("fee5").getValue().toString();
                    String vfee6 = dataSnapshot.child("fee6").getValue().toString();
                    String vfee7 = dataSnapshot.child("fee7").getValue().toString();
                    String vtotal = dataSnapshot.child("total").getValue().toString();

                    String vsub1 = dataSnapshot.child("sub1").getValue().toString();
                    String vsub2 = dataSnapshot.child("sub2").getValue().toString();
                    String vsub3 = dataSnapshot.child("sub3").getValue().toString();
                    String vsub4 = dataSnapshot.child("sub4").getValue().toString();
                    String vsub5 = dataSnapshot.child("sub5").getValue().toString();
                    String vsub6 = dataSnapshot.child("sub6").getValue().toString();
                    String vsub7 = dataSnapshot.child("sub7").getValue().toString();


                    fee1.setText("0");
                    fee2.setText("0");
                    fee3.setText("0");
                    fee4.setText("0");
                    fee5.setText("0");
                    fee6.setText("0");
                    fee7.setText("0");

                    sub1.setText(vsub1);
                    sub2.setText(vsub2);
                    sub3.setText(vsub3);
                    sub4.setText(vsub4);
                    sub5.setText(vsub5);
                    sub6.setText(vsub6);
                    sub7.setText(vsub7);



            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void paytofirstsem() {
        //connection
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();
        DatabaseReference myref = FirebaseDatabase.getInstance().getReference("users").child(userid);


        String mysub1 = sub1.getText().toString();
        String mysub2 = sub2.getText().toString();
        String mysub3 = sub3.getText().toString();
        String mysub4 = sub4.getText().toString();
        String mysub5 = sub5.getText().toString();
        String mysub6 = sub6.getText().toString();
        String mysub7 = sub7.getText().toString();

        String myfee1 = fee1.getText().toString();
        String myfee2 = fee2.getText().toString();
        String myfee3 = fee3.getText().toString();
        String myfee4 = fee4.getText().toString();
        String myfee5 = fee5.getText().toString();
        String myfee6 = fee6.getText().toString();
        String myfee7 = fee7.getText().toString();
        String getotal = total.getText().toString();


        HashMap hasMap = new HashMap();
        hasMap.put("fee1",myfee1);
        hasMap.put("fee2",myfee2);
        hasMap.put("fee3",myfee3);
        hasMap.put("fee4",myfee4);
        hasMap.put("fee5",myfee5);
        hasMap.put("fee6",myfee6);
        hasMap.put("fee7",myfee7);

        hasMap.put("sub1",mysub1);
        hasMap.put("sub2",mysub2);
        hasMap.put("sub3",mysub3);
        hasMap.put("sub4",mysub4);
        hasMap.put("sub5",mysub5);
        hasMap.put("sub6",mysub6);
        hasMap.put("sub7",mysub7);

        hasMap.put("total",getotal);


        myref.child("firstsem").updateChildren(hasMap);

        paytobalance();
    }


    private void paytosecondsem() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();
        DatabaseReference myref = FirebaseDatabase.getInstance().getReference("users").child(userid);
        String mysub1 = sub1.getText().toString();
        String mysub2 = sub2.getText().toString();
        String mysub3 = sub3.getText().toString();
        String mysub4 = sub4.getText().toString();
        String mysub5 = sub5.getText().toString();
        String mysub6 = sub6.getText().toString();
        String mysub7 = sub7.getText().toString();
        String getotal = total.getText().toString();

        String myfee1 = fee1.getText().toString();
        String myfee2 = fee2.getText().toString();
        String myfee3 = fee3.getText().toString();
        String myfee4 = fee4.getText().toString();
        String myfee5 = fee5.getText().toString();
        String myfee6 = fee6.getText().toString();
        String myfee7 = fee7.getText().toString();

        int newfee1 = Integer.parseInt(myfee1);
        int newfee2 = Integer.parseInt(myfee2);
        int newfee3 = Integer.parseInt(myfee3);
        int newfee4 = Integer.parseInt(myfee4);
        int newfee5 = Integer.parseInt(myfee5);
        int newfee6 = Integer.parseInt(myfee6);
        int newfee7 = Integer.parseInt(myfee7);




        HashMap hasMap = new HashMap();
        hasMap.put("fee1",myfee1);
        hasMap.put("fee2",myfee2);
        hasMap.put("fee3",myfee3);
        hasMap.put("fee4",myfee4);
        hasMap.put("fee5",myfee5);
        hasMap.put("fee6",myfee6);
        hasMap.put("fee7",myfee7);

        hasMap.put("sub1",mysub1);
        hasMap.put("sub2",mysub2);
        hasMap.put("sub3",mysub3);
        hasMap.put("sub4",mysub4);
        hasMap.put("sub5",mysub5);
        hasMap.put("sub6",mysub6);
        hasMap.put("sub7",mysub7);

        hasMap.put("total",getotal);

            myref.child("secondsem").updateChildren(hasMap).addOnSuccessListener(new OnSuccessListener() {
                @Override
                public void onSuccess(Object o) {

                    Intent reload = new Intent(getApplicationContext(), MainActivity.class);

                    startActivity(reload);
                }
            });
        paytobalance();

    }


    private void paytobalance() {
        if(validation()) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            String userid = user.getUid();
            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("users");
            DatabaseReference userRef = databaseRef.child(userid);

            //data time
            SimpleDateFormat ISO_8601_FORMAT = new SimpleDateFormat("MMMM dd yyyy hh:mm a");

            String now = ISO_8601_FORMAT.format(new Date());

            String status = "Pay-out";

            int zerobal = 0;

            if (check == "togglefirstsem"){
                sem = "first sem";
            }
            else if  (check == "toggle2ndsem") {
                sem = "second sem";
            }


            if (zerobal <= 0) {

                int numfee1 = Integer.parseInt(fee1.getText().toString());
                int numfee2 = Integer.parseInt(fee2.getText().toString());
                int numfee3 = Integer.parseInt(fee3.getText().toString());
                int numfee4 = Integer.parseInt(fee4.getText().toString());
                int numfee5 = Integer.parseInt(fee5.getText().toString());
                int numfee6 = Integer.parseInt(fee6.getText().toString());
                int numfee7 = Integer.parseInt(fee7.getText().toString());

                int totalresult = numfee1 + numfee2 + numfee3 + numfee4 + numfee5 + numfee6 + numfee7;


                int currentBalance = Integer.parseInt((txt_cash.getText().toString()));

                int paybal = currentBalance - totalresult;

                String Balance = "₱" + (String.valueOf(paybal));            //₱4000
                String addedbal = "-" + " " + String.valueOf((totalresult));


                userRef.child("balance").setValue(paybal);  //Balance

                firebaseDatabase = FirebaseDatabase.getInstance();
                databaseReference = firebaseDatabase.getReference("users").child(userid);

                employeeInfo = new EmployeeInfo(now, status, addedbal, Balance);

                databaseReference.child("history").push().setValue(employeeInfo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "Payment successfuly to " + sem, Toast.LENGTH_SHORT).show();
                                    Intent reload = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(reload);

                                } else {
                                    Toast.makeText(getApplicationContext(), "Payment failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            } else {
                Toast.makeText(getApplicationContext(), "Nooo", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void DisplayText() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userid = user.getUid();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users");

        ref.child(userid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String firstname = dataSnapshot.child("firstname").getValue().toString();
                String lastname = dataSnapshot.child("lastname").getValue().toString();
                String studno = dataSnapshot.child("studno").getValue().toString();
                String course = dataSnapshot.child("course").getValue().toString();
                String contact = dataSnapshot.child("contact").getValue().toString();
                String email = dataSnapshot.child("email").getValue().toString();
                String username = dataSnapshot.child("username").getValue().toString();
                String password = dataSnapshot.child("password").getValue().toString();
                String balance = dataSnapshot.child("balance").getValue().toString();

                profile_firstname.setText(firstname);
                profile_lastname.setText(lastname);
                profile_studno.setText(studno);
                profile_course.setText(course);
                profile_contact.setText(contact);
                profile_email.setText(email);
                profile_username.setText(username);
                txt_cash.setText(balance);

                edit_firstname.setText(firstname);
                edit_lastname.setText(lastname);
                edit_studno.setText(studno);
                edit_course.setText(course);
                edit_contact.setText(contact);
                edit_email.setText(email);
                edit_username.setText(firstname);
                edit_password.setText(password);


            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void updateBalance() {

        String contact = (String) profile_contact.getText();
        if ( contact.equals(cash_Contact.getText().toString())) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("users");
            String userid = user.getUid();
            DatabaseReference userRef = databaseRef.child(userid);

            SimpleDateFormat ISO_8601_FORMAT = new SimpleDateFormat("MMMM dd yyyy hh:mm a");
            String now = ISO_8601_FORMAT.format(new Date());
            String status = "Cash-in";

            Integer currentBalance = Integer.parseInt((txt_cash.getText().toString()));
            Integer amountToAdd =Integer.parseInt((cash_Amount.getText().toString()));

            int newBalance = currentBalance + amountToAdd;
            String Balance =  "₱" + String.valueOf(newBalance);
            String addedbal = "+" + " " + String.valueOf(amountToAdd);


            // instance of our FIrebase database.
            firebaseDatabase = FirebaseDatabase.getInstance();

            // below line is used to get reference for our database.
            databaseReference = firebaseDatabase.getReference("users").child(userid);

            employeeInfo = new EmployeeInfo(now, status, addedbal, Balance);
            databaseReference.child("history").push().setValue(employeeInfo)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "Database added successfuly", Toast.LENGTH_SHORT).show();
                                Intent reload = new Intent(getApplicationContext(), MainActivity.class);

                                startActivity(reload);

                            } else {
                                Toast.makeText(getApplicationContext(), "Database added failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

//            addDatatoFirebase(addedbal, Balance);

            userRef.child("balance").setValue(newBalance);
            cash_Contact.setText("");
            cash_Amount.setText("");
            txt_cash.setText(Balance);

        } else {
            Toast.makeText(getApplicationContext(), "Wrong Contact Number", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateProfile() {
        String firstname = edit_firstname.getText().toString().trim();
        String lastname = edit_lastname.getText().toString().trim();
        String studno = edit_studno.getText().toString().trim();
        String course = edit_course.getText().toString().trim();
        String contact = edit_contact.getText().toString().trim();
        String email = edit_email.getText().toString().trim();
        String username = edit_username.getText().toString().trim();
        String password = edit_password.getText().toString().trim();
        String confirm = edit_password2.getText().toString().trim();



        if (TextUtils.isEmpty(firstname)) {
            edit_firstname.setError("Please enter your first name!");
            return;
        }


        if (TextUtils.isEmpty(lastname)) {
            edit_lastname.setError("Please enter your last name!");
            return;
        }

        if (TextUtils.isEmpty(studno)) {
            edit_studno.setError("Please enter your student number!");
            return;
        }


        if (TextUtils.isEmpty(course)) {
            edit_course.setError("Please enter your course!");
            return;
        }

        if (TextUtils.isEmpty(contact)) {
            edit_contact.setError("Please enter your contact number!");
            return;
        }

        if (contact.length() !=11) {
            edit_contact.setError("Invalid contact number!");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            edit_email.setError("Please enter your email");
            return;
        }

        if (TextUtils.isEmpty(username)) {
            edit_username.setError("Please enter your username");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            edit_password.setError("Please enter your password!");
            return;
        }


        if ( confirm.equals(edit_password.getText().toString())) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("users");
            String userid = user.getUid();

            DatabaseReference userRef = databaseRef.child(userid);;

            userRef.child("firstname").setValue(firstname);
            userRef.child("lastname").setValue(lastname);
            userRef.child("studno").setValue(studno);
            userRef.child("course").setValue(course);
            userRef.child("contact").setValue(contact);
            userRef.child("email").setValue(email);
            userRef.child("username").setValue(username);
            userRef.child("password").setValue(password);


            profile_firstname.setText(firstname);
            profile_lastname.setText(lastname);
            profile_studno.setText(studno);
            profile_course.setText(course);
            profile_contact.setText(contact);
            profile_email.setText(email);
            profile_username.setText(username);
            profile_password.setText(password);
            edit_password2.setText("");


            Toast.makeText(getApplicationContext(), "Edit Successful", Toast.LENGTH_SHORT).show();
        } else {

            Toast.makeText(getApplicationContext(), "Edit Account Failed", Toast.LENGTH_SHORT).show();
        }
    }



    private boolean validation() {

        if (total.getText().toString().trim().equals("0")) {
            Toast.makeText(this, "Enter A data first", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void gotohistory() {
        Intent i = new Intent(MainActivity.this, History.class);
        startActivity(i);
        finish();

    }
}
