package com.example.interbal;


public class EmployeeInfo {
    private String now, status, addedbal, Balance;

    public EmployeeInfo() {
        // Default constructor required for Firebase
    }



    public EmployeeInfo(String now, String status, String addedbal, String Balance) {
        this.now = now;
        this.status = status;
        this.addedbal = addedbal;
        this.Balance = Balance;
    }

    public String getNow() {
        return now;
    }

    public String getStatus() {
        return status;
    }

    public String getAddedbal() {
        return addedbal;
    }

    public String getBalance() {
        return Balance;
    }

    public void setNow(String now) {
        this.now = now;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setAddedbal(String addedbal) {
        this.addedbal = addedbal;
    }

    public void setBalance(String balance) {
        Balance = balance;
    }

}